# Google Data Loss Prevention (DLP) API

The Google Data Loss Prevention API provides methods for detection
of privacy-sensitive fragments in text, images, and Google Cloud
Platform storage repositories.

Documentation: https://cloud.google.com/dlp/docs
